NES colours SD skin by Gilou9999

Everyone thought it was impossible to have a true HD user interface for Xport/madmab emus (even me, and even madmab lol). After lot of testing and some tricks i discovered it to be possible using a sprite trick, in fact using the sprites system to display backgrounds; and also using some special screen size numbers (the scale system is weird). I kept the stretched version of the 640*480 backgrounds in the skin root, or else you won't have the skin transitions effects (the true hd backgrounds are in the sprites folder). 

The main screen can be 1280*960 in most case; with the exception of the memory eaters emus (neogenesis,winuaex,winstonx,dosxbox,bluemsx); in theyr case the main screen can be 1068*800 or 915*685 pixels max (wich is still 50% better quality than any old Xport's skins). 
So finally i release this pack of HD skins. Be aware the gameselect screen can have a max screensize of 915*685 (or else the emu won't display the background or will crash).

Thanks to Madmab for his great releases and emus updates and Thanks to grospixels (www.grospixels.com)for their excellents remixed videogames musics.
