For features and description, please see UnleashX documentation, or the change
logs for the last 3 releases, or so ;).


****	Change Log	****

UnleashX V0.39.0528 Build 584
Version:	0.39 Build 584
Status		Alpha
Release Date:	05/28/2007



*Fixed	Problem displaying Zipped skins properly.
*Fixed	Black color in images are rendered as transparent.
*Fixed	Dash lockup when scrolling up in Game Manager.
*Fixed	MP3 files are now playable directly from USB FAT32 devices.

*Changed	z-buffer bit depth to 16-bit from 32-bit to decrease
		memory footprint.

*Added	"Compress Texture" in video settings. Default is Off/No/False.
	Settings this to true enables the Dash to use Texture compression
	for big images, decreasing the memory requirement to display those
	in exchange for a lesser quality image. You can set this to "Yes" if
	you are using a skin with lots of videos/images 
*Added	"Browse Folder" in Music manager. You can now select folders
	containing MP3 and WMA files and the dash will queue them
*Added	WMA playback support for ISO9660 disc/USB FAT32 devices.
	Note: Files are copied to a temp folder. File streaming in XACT
	appears to be broken so I can't play from the media source directly.


Note: 	Live Update server will only work with V0.39.0515A Build 583. If you are 
	manually updating the dash, you only need to copy Default.xbe and
	replace your dash. Do not copy config.xml as this will overwrite your
	settings.
